# Logs
Log generated during session by aircrack-ng is stored here. The file is overwritten for each session.
> password - contains standard output stream i.e. >

> error - contains standard error stream i.e. 2>
